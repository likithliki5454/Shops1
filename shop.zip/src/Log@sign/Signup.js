import React from "react";
import "./App.css";
export default function Signup() {
  return (
    <div>
      
        <div id="img">
          <img src="/edited.jpg"></img>
        </div>


    </div>
  );
}
