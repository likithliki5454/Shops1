const list = [
  {
    id: 1,
    title: "Clean code",
    author: " Book House",
    img: "clean code.jpg",
    amount: 1,
  },
  {
    id: 2,
    title: "Clean Architecture",
    author: " Book House",
    img: "clean architecture.jpg",
    amount: 1,
  },
  {
    id: 3,
    title: "Clean code in Python",
    author: " Book House",
    img: "clean code in python.png",
    amount: 1,
  },
  {
    id: 4,
    title: "Practcal API Design",
    author: " Book House",
    img: "Practcal api design.png",
    amount: 1,
  },
  {
    id: 5,
    title: "Docker Demystified",
    author: " Book House",
    img: "Docker Demystified.webp",
    amount: 1,
  },
  {
    id: 6,
    title: "Introduction to data science",
    author: " Book House",
    img: "introduction to data science.png",
    amount: 1,
  },
  {
    id: 7,
    title: "Java professional guide",
    author: " Book House",
    img: "Java professional guide.png",
    amount: 1,
  },
  {
    id: 8,
    title: "Ruby devolepers guide",
    author: " Book House",
    img: "Ruby devolepers guide.png",
    amount: 1,
  },
  {
    id: 9,
    title: "Design pattrens",
    author: " Book House",
    img: "Design pattrens.jpg",
    amount: 1,
  },
];

export default list;
